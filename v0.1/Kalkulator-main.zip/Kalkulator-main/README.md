Latihan JavaScript #1 (Kalkulator) 
Status = Belum Selesai
